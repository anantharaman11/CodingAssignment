#!/usr/bin/env python
# coding: utf-8

# In[1]:


import configparser

class Inventory():
    '''
        Class that provides information on Product ID, Name and Price.
        
        Attributes:
            __item (dict): Holds product information
        
        Methods:
            add_item(iid, name, price)
                Add the product to inventory   
            list_item()
                Prints the list of products
            get_items()
                Get the complete set of products 
    '''
    
    def __init__(self):
        
        '''Constructor for class Inventory that defines the item dictionary.'''
        
        self.__item = {}
    
    def add_item(self, iid, name, price):
        
        """
            Adds the product to inventory
            
            Parameters:
                iid : str
                    Short identifier of the product added
                name : str
                    Name of the product added
                price : float64
                    Price of the product added
            
            Returns:
                None
        """
        self.__item[iid] = [name, price]
        
    def list_item(self):
        
        """
            Prints the list of available products and its details
            
            Parameters:
               None
            
            Returns:
                None
        """
        
        print(self.__item)
        
    def get_items(self):
        
        """
            Get the list of available products
            
            Parameters:
                None
            
            Returns:
                __item : dict
        """
        
        return self.__item
    
# Object creation
inv = Inventory()

# Adding items as described in the problem statement
config_file_path = input('Enter the path of config file: ')
config = configparser.ConfigParser()
config.read(config_file_path)
pid_ls = [x.strip() for x in config['ProductDetails']['ProductID'].split(',')]
pname_ls = [x.strip() for x in config['ProductDetails']['ProductName'].split(',')]
price_ls = [float(x.strip()) for x in config['ProductDetails']['Price'].split(',')]
for i in range(len(pid_ls)):
    inv.add_item(pid_ls[i], pname_ls[i], price_ls[i])

# Printing the items added
#inv.list_item()


# In[2]:


class PricingRules():
    
    '''
        Class that sets the input parameters for discounted pricing calculation
        
        Attributes:
            __pricing_rule (dict): Input parameters for discount pricing rule
        
        Methods:
            add_rule(iid, discount_type, discount_threshold=None, discount_metadata=None, discount_amount=None, free_item=None)
                Add the parameters for the pricing rule calculation   
            get_rules()
                Get the set of pricing rule parameters.
            show_rule()
                Prints the list of pricing rule parameters.
            get_inventory_details()
                Get the product information
    '''
    
    def __init__(self, inventory):
        
        '''
            Constructor for class PricingRules that defines the pricing_rule dictionary and 
            initializes with inventory object.
           
        '''
        
        self.__pricing_rule = {}
        self.inventory = inventory
    
    def add_rule(self, iid, discount_type, discount_threshold=None, discount_metadata=None, discount_amount=None, free_item=None):
       
        """
            Adds the parameters for pricing rule formulation
            
            Parameters:
                iid : str
                    Short identifier of the product
                discount_type : str
                    Type of discount provided
                discount_threshold : int, optional
                    Minimum number of units to be purchased to provide discount
                discount_metadata : int, optional
                    Secondary discount information for certain discount type
                discount_amount : float64, optional
                    Discount amount finalized
                free_item : str, optional
                    Product ID of free item provides due to discount
                    
            Returns:
                None
        """
        
        self.__pricing_rule[iid] = [discount_type, discount_threshold, discount_metadata, discount_amount, free_item]
        
    def get_rules(self):
        
        """
            Get the pricing rule parameters
            
            Parameters:
                None
            
            Returns:
                __pricing_rule : dict
        """
        
        return self.__pricing_rule
        
    def show_rule(self):
        
        """
            Prints the list of pricing rule parameters
            
            Parameters:
               None
            
            Returns:
                None
        """
        
        print(self.__pricing_rule)
        
    def get_inventory_details(self):
        
        """
            Get the list of products
            
            Parameters:
                None
            
            Returns:
                item : dict
        """
        
        return self.inventory.get_items()

# Object creation    
pr = PricingRules(inv)

# Adding input parameters to formulate pricing rule as described in the problem statement
for i in range(1, len(pid_ls)+1):
    node = 'PricingRule'+str(i)
    ProductID = config[node]['ProductID'].lower()
    DiscountType = config[node]['DiscountType']
    DiscountThreshold = None if config[node]['DiscountThreshold'].lower() == 'none' else int(config[node]['DiscountThreshold'])
    DiscountMetadata = None if config[node]['DiscountMetadata'].lower() == 'none' else int(config[node]['DiscountMetadata']) 
    DiscountAmount = None if config[node]['DiscountAmount'].lower() == 'none' else float(config[node]['DiscountAmount'])  
    FreeItem = None if config[node]['FreeItem'].lower() == 'none' else config[node]['FreeItem'].lower()   
    pr.add_rule(ProductID, DiscountType, DiscountThreshold, DiscountMetadata, DiscountAmount, FreeItem)

# Printing the input parameters for pricing rule
#pr.show_rule()


# In[3]:


class DiscountCalculation():
    
    '''
        Class for calculating the discounted price for the product purchase. 
        
        ** As new discount types are introduced, corresponding function definitions will be added in this class, as needed
        
        Methods:
            calculate_discount(iid, item_count, price, pricing_rule_param)
                Master method that triggers function calls for each type of discount   
            price_drop()
                Calculate discount for the Price drop category
            buy_n_get_m()
                Calculate discount for the Buy N Get M category
    '''
    
    def __init__(self):
        
        """ Placeholder constructor """
        pass

    def calculate_discount(self, iid, item_count, price, pricing_rule_param):
                   
        """
            Adds the parameters for pricing rule formulation
             
             Parameters:
                 iid : str
                     Short identifier of the product purchased
                 item_count : int
                     Count of products/items purchased
                 price : float
                     Price of the purchased item/product (per entity price) 
                 pricing_rule_param : list
                     Parameter set used for pricing rule formulation
                     
             Returns:
                 Tuple (int, int)
                    item_count : int
                    price : float
        """
        
        if(pricing_rule_param[0] == 'Price_Drop'):
            return self.price_drop(item_count, price, pricing_rule_param[3])
        elif(pricing_rule_param[0] == 'N_For_M_Deal'):
            return self.buy_n_get_m(item_count, pricing_rule_param[1], pricing_rule_param[2], price)
        else: 
            # Handles the cases of - No discount and Free item discount category
            return item_count, price 
               
    def price_drop(self, item_count, price, discount_amount):
        
        """
            Helper method to calculate the discounted price for Price drop category
            
            Parameters:
                item_count : int
                     Count of products/items purchased
                 price : float
                     Price of the purchased item/product (per entity price) 
                discount_amount : float
                    Discount amount of the product
            
            Returns:
                Tuple (int, int)
                    item_count : int
                    discounted price : float
        """
        discounted_price = (price - discount_amount)
        return item_count, discounted_price
    
    def buy_n_get_m(self, item_count, n, m, price):
        """
           Helper method to calculate the discounted price for Buy N Get M category
           
           Parameters:
               item_count : int
                    Count of products/items purchased
                price : float
                    Price of the purchased item/product (per entity price) 
               n : int
                   Actual number of items to be purchased to get discount
               m : int
                   Actual number of items that will be charged
           
           Returns:
               Tuple (int, int)
                   items_charged : int
                   price : float
         """
        
        items_charged = ((item_count%n) + (item_count//n) * m)
        return items_charged, price
    


# In[6]:


class Checkout():
    
    '''
        Class that scans the purchased product and calculates the total price of the purchase
        
        Methods:
            scan(item)
                Scans or adds the purchased product/item   
            get_purchase_items()
                Gets the complete set of purchased items
            total()
                Calculate total discounted price of the purchased products
    '''
        
    def __init__(self, pricing_rule):
        
        '''
            Constructor for class Checkout that defines the purchase_item dictionary and 
            initializes with pricing_rule object.
           
        '''
            
        self.__purchase_item = {}
        self.pricing_rule = pricing_rule
    
    def scan(self, item):
        
        """
            Scans the purchased product
            
            Parameters:
                item : str
                    Product ID of purchased item
            
            Returns:
                None
        """
        
        self.__purchase_item[item] = self.__purchase_item.get(item, 0) + 1
        
    def get_purchase_items(self):
        
        """
            Get the list of purchased products
            
            Parameters:
                None
            
            Returns:
                __purchase_item : dict
        """
        
        return self.__purchase_item
        
    def total(self):
        
        """
            Outputs the total discounted price of the purchase
            
            Parameters:
                None
            
            Returns:
                total_price : float
        """
            
        total_price = 0
        checkout_summary = {}
        rule = self.pricing_rule.get_rules()
        inventory = self.pricing_rule.get_inventory_details()
        dc = DiscountCalculation()
        
        # iterates over the purchased item and calculates the discounted price
        for k, v in self.__purchase_item.items():
            if(rule[k][1]!=None):
                if(v >= rule[k][1]):
                    checkout_summary[k] = dc.calculate_discount(k, v, inventory[k][1], rule[k])
                    # Additional logic to handle Free item category of discount. 
                    # Pop out charger for each Central AC purchase
                    if((rule[k][0] == 'Free_Item') & (self.__purchase_item.get(rule[k][4], 0) != 0)):
                        free_item_count = self.__purchase_item.get(rule[k][4], 0) - v
                        self.__purchase_item[rule[k][4]] = free_item_count if(free_item_count >= 0) else 0
                else:
                    checkout_summary[k] = v, inventory[k][1]
            else:
                checkout_summary[k] = v, inventory[k][1]
                
        for i in checkout_summary.values():
            total_price += i[0]*i[1]
         
        total_price = round(total_price,2)
        return total_price
        
co = Checkout(pr)
scan_inp = [x.strip() for x in config['ScanInput']['ITEM_IDs_Scanned'].split(',')]
for i in range(len(scan_inp)):
    co.scan(scan_inp[i])

print("Item IDs Scanned: {}".format(str(config['ScanInput']['ITEM_IDs_Scanned'])))
print('Expected total: ${}'.format(co.total()))
input()
input()


# In[ ]:




